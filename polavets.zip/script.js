const selectEl = document.getElementById('select');
const registrationImage = document.getElementById('coliseum-img');
const textToChange = document.getElementById('text-to-change');
const labels = document.querySelectorAll('label');
const options = document.querySelectorAll('option');
const button = document.querySelector('.form-submit-button');


selectEl.addEventListener('change', function() {
switch(true) {
    case this.value === 'china_wall' : registrationImage.src = "./Assets/china_wall.png";
    break;
    case this.value === 'coliseum' : registrationImage.src = "./Assets/Coliseum.png";
    break;
    case this.value === "elf_tower" : registrationImage.src = "./Assets/elf_tower.png";
    break;
    case this.value === "taj_mahal" : registrationImage.src = "./Assets/taj mahal.png";
    break;
    case this.value === "statue_of_liberty" : registrationImage.src = "./Assets/statue of liberty.png";
    break;
    case this.value === "big_ben" : registrationImage.src = "./Assets/big ben.png";
    break;
    default: setSneakyRicardo(this); 
}

})

button.addEventListener('click', function() {
    console.log(this.className);
    this.classList.toggle('form-submit-button');
})
